import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const shelters = [
  { name: 'Westbahn Shelter', beds: 3, address: 'Westbahnstraße 44' },
  { name: 'St. Joseph’s Home', beds: 0, address: 'Felberstraße 32' },
  { name: 'Mariahilf Shelter', beds: 5, address: 'Mariahilfer Gürtel 8' },
];

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.logo}>shelterhelper</Text>
      <Text style={styles.header}>Shelters in Vienna</Text>

      <TouchableOpacity style={styles.mapButton}>
        <Ionicons name="location-outline" size={22} color="#000" />
        <Text style={styles.mapButtonText}>View Map</Text>
      </TouchableOpacity>

      <FlatList
        data={shelters}
        keyExtractor={(item) => item.name}
        renderItem={({ item }) => {
          let dotColor = 'green';
          if (item.beds === 0) {
            dotColor = 'red';
          } else if (item.beds <= 3) {
            dotColor = 'orange';
          }

          return (
            <View style={styles.card}>
              <View>
                <Text style={styles.shelterName}>{item.name}</Text>
                <View style={styles.bedStatusContainer}>
                  <View
                    style={[styles.statusDot, { backgroundColor: dotColor }]}
                  />
                  <Text style={styles.beds}>
                    {item.beds === 0
                      ? 'Full'
                      : `${item.beds} beds available`}
                  </Text>
                </View>
                <Text style={styles.address}>{item.address}</Text>
              </View>
              <Ionicons
                name="chevron-forward-outline"
                size={20}
                color="#888"
              />
            </View>
          );
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 50,
    backgroundColor: '#F8F6F2',
  },
  logo: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  header: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: 20,
    color: '#111',
  },
  mapButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EDEDED',
    borderRadius: 12,
    padding: 14,
    marginBottom: 24,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  mapButtonText: {
    fontSize: 16,
    marginLeft: 10,
    fontWeight: '500',
  },
  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFF',
    padding: 16,
    paddingHorizontal: 20, // Hier wurde der Wert von 16 auf 20 geändert, um 4px links und rechts hinzuzufügen (16 + 4 = 20)
    borderRadius: 14,
    marginBottom: 14,
    borderColor: '#E0E0E0',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  shelterName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#222',
  },
  bedStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  beds: {
    fontSize: 15,
    color: '#444',
  },
  address: {
    marginTop: 2,
    color: '#777',
    fontSize: 14,
  },
});